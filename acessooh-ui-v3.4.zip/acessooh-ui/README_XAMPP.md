# AcessoOH UI v3.4 — Sem dependência de gráficos externos (SVG puro)
## Dev
npm install
npm run dev
## Build
npm run build
## XAMPP
Copie dist para C:\xampp\htdocs\acessooh e acesse http://localhost/acessooh/
