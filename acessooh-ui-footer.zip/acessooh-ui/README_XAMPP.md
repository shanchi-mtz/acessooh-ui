# AcessoOH UI (Vite + React + Tailwind) — Nav no rodapé
## 1) Dev
npm install
npm run dev
## 2) Build
npm run build
## 3) XAMPP
Copie a pasta `dist` para `C:\xampp\htdocs\acessooh` e acesse `http://localhost/acessooh/`.
