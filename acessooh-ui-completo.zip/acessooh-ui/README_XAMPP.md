# AcessoOH UI — Sidebar fixa + Drawer mobile + Footer nav
## Dev
npm install
npm run dev
## Build
npm run build
## XAMPP
Copie `dist` para `C:\xampp\htdocs\acessooh` e acesse `http://localhost/acessooh/`.
