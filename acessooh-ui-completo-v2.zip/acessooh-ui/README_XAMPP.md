# AcessoOH UI — Login sem menu, sidebar após login, foto com blur
## Dev
npm install
npm run dev
## Build
npm run build
## XAMPP
Copie `dist` para `C:\xampp\htdocs\acessooh` e acesse `http://localhost/acessooh/`.
