# AcessoOH UI v3.3 — Completo
## Dev
npm install
npm run dev
## Build
npm run build
## XAMPP
Copie dist para C:\xampp\htdocs\acessooh e acesse http://localhost/acessooh/
